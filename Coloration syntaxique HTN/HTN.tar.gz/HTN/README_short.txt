#################################################################
myPDDL 1.0 - The Modular Knowledge Engineering Toolkit for PDDL
Written in 2014 by Volker Strobel at the University of Tuebingen.
#################################################################

#######
Usage:
#######

myPDDL:
new <project-name>              Create a PDDL project  
diagram <pddl-domain-file>      Display a PDDL type diagram
distance <pddl-problem-file>    Calculate distances between objects 
