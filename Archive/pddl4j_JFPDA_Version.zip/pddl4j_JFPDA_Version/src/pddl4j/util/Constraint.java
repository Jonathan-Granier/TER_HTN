package pddl4j.util;

public interface Constraint {

}
