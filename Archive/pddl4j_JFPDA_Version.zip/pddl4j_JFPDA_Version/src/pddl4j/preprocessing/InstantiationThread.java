package pddl4j.preprocessing;

/**
 * TODO
 * 
 * @since
 */
public class InstantiationThread
extends Thread {
	
	public InstantiationThread(final String name) {
		super(name);
	}
	
	public void run() {
	
	}
	
}
